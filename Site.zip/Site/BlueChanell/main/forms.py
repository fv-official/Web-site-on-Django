from .models import Register
from django.forms import ModelForm, EmailInput, PasswordInput, TextInput


class RegisterForm(ModelForm):
    class Meta:
        model = Register
        fields = ["mail", "password", "surname", "name", "middlename"]
        widgets = {
            "mail": EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Example@gmail.com'
            }),
            "password": PasswordInput(attrs={
                'class': 'form-control',
                'placeholder': 'Пароль'
            }),
            "surname": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Фамилия'
            }),
            "name": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Имя'
            }),
            "middlename": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Отчество'
            })

        }
