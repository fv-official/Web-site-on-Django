from django.db import models


class Register(models.Model):
    mail = models.EmailField('Почта', max_length=100)
    password = models.CharField('Пароль', max_length=100)
    surname = models.CharField('Фамилия', max_length=100)
    name = models.CharField('Имя', max_length=100)
    middlename = models.CharField('Отчество', max_length=100)

    def __str__(self):
        return self.mail
