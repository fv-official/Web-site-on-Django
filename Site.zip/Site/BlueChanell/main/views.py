from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Register
from .forms import RegisterForm
from django.shortcuts import render


def reg(request):
    error = ''
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
        else:
            error = '110'

    form = RegisterForm()
    context = {
        'form': form
    }
    return render(request, 'main/reg.html', context)


def index(request):
    return render(request, 'main/index.html')


def about(request):
    return render(request, 'main/about.html')
